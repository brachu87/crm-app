const express = require('express');
const prisma = require('../prisma');
const authMiddleware = require('../middleware/auth');
const { scopedWhere } = require('../middleware/tenant');

const router = express.Router();

router.use(authMiddleware);

// GET /api/activities - lista actividades con cantidad de inscriptos
router.get('/', async (req, res) => {
  try {
    const activities = await prisma.activity.findMany({
      where: scopedWhere(req),
      include: {
        _count: { select: { enrollments: true } },
      },
      orderBy: { name: 'asc' },
    });
    res.json(activities);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al obtener actividades' });
  }
});

// GET /api/activities/:id - detalle + lista de clientes inscriptos con estado de pago
router.get('/:id', async (req, res) => {
  try {
    const activity = await prisma.activity.findFirst({
      where: scopedWhere(req, { id: req.params.id }),
      include: {
        enrollments: {
          include: { client: true },
          orderBy: { client: { name: 'asc' } },
        },
      },
    });

    if (!activity) return res.status(404).json({ error: 'Actividad no encontrada' });

    res.json(activity);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al obtener actividad' });
  }
});

// POST /api/activities - crear actividad
router.post('/', async (req, res) => {
  try {
    const { name, description, price, capacity, schedule } = req.body;

    if (!name || price === undefined) {
      return res.status(400).json({ error: 'Nombre y precio son obligatorios' });
    }

    const activity = await prisma.activity.create({
      data: {
        name,
        description,
        price,
        capacity,
        schedule,
        businessId: req.user.businessId,
      },
    });

    res.status(201).json(activity);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al crear actividad' });
  }
});

// PUT /api/activities/:id - editar actividad
router.put('/:id', async (req, res) => {
  try {
    const existing = await prisma.activity.findFirst({
      where: scopedWhere(req, { id: req.params.id }),
    });
    if (!existing) return res.status(404).json({ error: 'Actividad no encontrada' });

    const { name, description, price, capacity, schedule, active } = req.body;

    const activity = await prisma.activity.update({
      where: { id: req.params.id },
      data: { name, description, price, capacity, schedule, active },
    });

    res.json(activity);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al editar actividad' });
  }
});

// DELETE /api/activities/:id
router.delete('/:id', async (req, res) => {
  try {
    const existing = await prisma.activity.findFirst({
      where: scopedWhere(req, { id: req.params.id }),
    });
    if (!existing) return res.status(404).json({ error: 'Actividad no encontrada' });

    await prisma.activity.delete({ where: { id: req.params.id } });

    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al eliminar actividad' });
  }
});

module.exports = router;
