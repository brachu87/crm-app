import { NavLink, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const links = [
  { to: '/', label: 'Inicio', icon: '◆' },
  { to: '/actividades', label: 'Actividades', icon: '◆' },
  { to: '/clientes', label: 'Clientes', icon: '◆' },
  { to: '/cobranza', label: 'Cobranza', icon: '◆' },
];

export default function Layout() {
  const { business, logout } = useAuth();

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand">
          {business?.name || 'Mi Negocio'}
        </div>
        {links.map((link) => (
          <NavLink
            key={link.to}
            to={link.to}
            end={link.to === '/'}
            className={({ isActive }) => `sidebar-link${isActive ? ' active' : ''}`}
          >
            {link.label}
          </NavLink>
        ))}
        <div className="sidebar-footer">
          {business?.category && <div>{business.category}</div>}
          <button onClick={logout}>Cerrar sesión</button>
        </div>
      </aside>
      <main className="main">
        <Outlet />
      </main>
    </div>
  );
}
