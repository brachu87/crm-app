import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/client';

const statusLabels = {
  paid: 'Pagado',
  pending: 'Pendiente',
  overdue: 'Vencido',
};

const filters = [
  { value: '', label: 'Todos' },
  { value: 'pending', label: 'Pendientes' },
  { value: 'overdue', label: 'Vencidos' },
  { value: 'paid', label: 'Pagados' },
];

function formatMoney(value) {
  return new Intl.NumberFormat('es-AR', { style: 'currency', currency: 'ARS', maximumFractionDigits: 0 }).format(value || 0);
}

function formatDate(value) {
  if (!value) return '-';
  return new Date(value).toLocaleDateString('es-AR');
}

export default function Collections() {
  const [enrollments, setEnrollments] = useState([]);
  const [status, setStatus] = useState('pending');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    const query = status ? `?status=${status}` : '';
    api.get(`/enrollments${query}`).then((res) => setEnrollments(res.data)).finally(() => setLoading(false));
  }, [status]);

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Cobranza</h1>
          <p className="page-subtitle">Quién te debe y quién está al día</p>
        </div>
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
        {filters.map((f) => (
          <button
            key={f.value}
            className={`btn btn-sm ${status === f.value ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setStatus(f.value)}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="card">
        {loading ? (
          <p>Cargando...</p>
        ) : enrollments.length === 0 ? (
          <div className="empty-state">
            <h3>Nada por aquí</h3>
            <p>No hay inscripciones con este estado.</p>
          </div>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Cliente</th>
                <th>Actividad</th>
                <th>Monto</th>
                <th>Vence</th>
                <th>Estado</th>
              </tr>
            </thead>
            <tbody>
              {enrollments.map((e) => (
                <tr key={e.id}>
                  <td><Link to={`/clientes/${e.clientId}`}>{e.client.name}</Link></td>
                  <td><Link to={`/actividades/${e.activityId}`}>{e.activity.name}</Link></td>
                  <td>{formatMoney(e.amountDue)}</td>
                  <td>{formatDate(e.dueDate)}</td>
                  <td><span className={`pill pill-${e.paymentStatus}`}>{statusLabels[e.paymentStatus]}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
