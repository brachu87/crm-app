import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import api from '../api/client';

const statusLabels = {
  paid: 'Pagado',
  pending: 'Pendiente',
  overdue: 'Vencido',
};

function formatMoney(value) {
  return new Intl.NumberFormat('es-AR', { style: 'currency', currency: 'ARS', maximumFractionDigits: 0 }).format(value || 0);
}

function formatDate(value) {
  if (!value) return '-';
  return new Date(value).toLocaleDateString('es-AR');
}

export default function ClientDetail() {
  const { id } = useParams();
  const [client, setClient] = useState(null);
  const [loading, setLoading] = useState(true);
  const [payModal, setPayModal] = useState(null);
  const [error, setError] = useState('');

  function load() {
    api.get(`/clients/${id}`).then((res) => setClient(res.data)).finally(() => setLoading(false));
  }

  useEffect(load, [id]);

  async function registerPayment(enrollmentId, amount, method) {
    try {
      await api.post(`/enrollments/${enrollmentId}/pay`, { amount: Number(amount), method: method || undefined });
      setPayModal(null);
      load();
    } catch {
      setError('No se pudo registrar el pago');
    }
  }

  if (loading) return <p>Cargando...</p>;
  if (!client) return <p>Cliente no encontrado.</p>;

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>{client.name}</h1>
          <p className="page-subtitle">
            {client.phone || 'Sin teléfono'} {client.email ? `· ${client.email}` : ''}
          </p>
        </div>
        <Link to="/clientes" className="btn btn-secondary">Volver</Link>
      </div>

      {error && <div className="error-banner">{error}</div>}

      {client.notes && (
        <div className="card" style={{ marginBottom: 20 }}>
          <strong>Notas:</strong> {client.notes}
        </div>
      )}

      <h2 style={{ fontSize: 18, marginBottom: 12 }}>Actividades</h2>
      {client.enrollments.length === 0 ? (
        <div className="card">
          <div className="empty-state">
            <h3>No está inscripto en ninguna actividad</h3>
            <p>Ve a la actividad correspondiente para inscribir a este cliente.</p>
          </div>
        </div>
      ) : (
        <div className="card" style={{ marginBottom: 24 }}>
          <table className="table">
            <thead>
              <tr>
                <th>Actividad</th>
                <th>Monto</th>
                <th>Vence</th>
                <th>Estado</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {client.enrollments.map((e) => (
                <tr key={e.id}>
                  <td><Link to={`/actividades/${e.activityId}`}>{e.activity.name}</Link></td>
                  <td>{formatMoney(e.amountDue)}</td>
                  <td>{formatDate(e.dueDate)}</td>
                  <td><span className={`pill pill-${e.paymentStatus}`}>{statusLabels[e.paymentStatus]}</span></td>
                  <td>
                    {e.paymentStatus !== 'paid' && (
                      <button className="btn btn-secondary btn-sm" onClick={() => setPayModal(e)}>Registrar pago</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <h2 style={{ fontSize: 18, marginBottom: 12 }}>Historial de pagos</h2>
      <div className="card">
        {client.enrollments.every((e) => e.payments.length === 0) ? (
          <div className="empty-state">
            <h3>Sin pagos registrados</h3>
          </div>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Fecha</th>
                <th>Actividad</th>
                <th>Monto</th>
                <th>Método</th>
              </tr>
            </thead>
            <tbody>
              {client.enrollments.flatMap((e) =>
                e.payments.map((p) => (
                  <tr key={p.id}>
                    <td>{formatDate(p.date)}</td>
                    <td>{e.activity.name}</td>
                    <td>{formatMoney(p.amount)}</td>
                    <td>{p.method || '-'}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        )}
      </div>

      {payModal && (
        <PayModal
          enrollment={payModal}
          onClose={() => setPayModal(null)}
          onConfirm={registerPayment}
        />
      )}
    </div>
  );
}

function PayModal({ enrollment, onClose, onConfirm }) {
  const [amount, setAmount] = useState(enrollment.amountDue);
  const [method, setMethod] = useState('efectivo');
  const [saving, setSaving] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    await onConfirm(enrollment.id, amount, method);
    setSaving(false);
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <h2>Registrar pago — {enrollment.activity.name}</h2>
        <form onSubmit={handleSubmit}>
          <div className="field">
            <label>Monto</label>
            <input type="number" min="0" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} required />
          </div>
          <div className="field">
            <label>Método</label>
            <select value={method} onChange={(e) => setMethod(e.target.value)}>
              <option value="efectivo">Efectivo</option>
              <option value="transferencia">Transferencia</option>
              <option value="mercadopago">Mercado Pago</option>
              <option value="tarjeta">Tarjeta</option>
            </select>
          </div>
          <div className="modal-actions">
            <button type="button" className="btn btn-secondary" onClick={onClose}>Cancelar</button>
            <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Guardando...' : 'Confirmar pago'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}
