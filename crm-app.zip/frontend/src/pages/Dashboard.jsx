import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/client';

const statusLabels = {
  paid: 'Pagado',
  pending: 'Pendiente',
  overdue: 'Vencido',
};

function formatMoney(value) {
  return new Intl.NumberFormat('es-AR', { style: 'currency', currency: 'ARS', maximumFractionDigits: 0 }).format(value || 0);
}

function formatDate(value) {
  if (!value) return '-';
  return new Date(value).toLocaleDateString('es-AR');
}

export default function Dashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/dashboard').then((res) => setData(res.data)).finally(() => setLoading(false));
  }, []);

  if (loading) return <p>Cargando...</p>;
  if (!data) return <p>No se pudo cargar el resumen.</p>;

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Inicio</h1>
          <p className="page-subtitle">Resumen general de tu negocio</p>
        </div>
      </div>

      <div className="stat-grid">
        <div className="stat-card">
          <div className="stat-label">Clientes</div>
          <div className="stat-value">{data.clientsCount}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Actividades activas</div>
          <div className="stat-value">{data.activitiesCount}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Pagos pendientes</div>
          <div className="stat-value warn">{data.pending.count}</div>
          <div className="page-subtitle">{formatMoney(data.pending.total)}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Pagos vencidos</div>
          <div className="stat-value accent">{data.overdue.count}</div>
          <div className="page-subtitle">{formatMoney(data.overdue.total)}</div>
        </div>
      </div>

      <div className="card">
        <h2 style={{ fontSize: 18, marginBottom: 16 }}>Próximos vencimientos</h2>
        {data.upcomingDueDates.length === 0 ? (
          <div className="empty-state">
            <h3>Sin vencimientos pendientes</h3>
            <p>Cuando inscribas clientes con fecha de vencimiento, los vas a ver acá.</p>
          </div>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Cliente</th>
                <th>Actividad</th>
                <th>Vence</th>
                <th>Monto</th>
                <th>Estado</th>
              </tr>
            </thead>
            <tbody>
              {data.upcomingDueDates.map((e) => (
                <tr key={e.id}>
                  <td><Link to={`/clientes/${e.clientId}`}>{e.client.name}</Link></td>
                  <td>{e.activity.name}</td>
                  <td>{formatDate(e.dueDate)}</td>
                  <td>{formatMoney(e.amountDue)}</td>
                  <td><span className={`pill pill-${e.paymentStatus}`}>{statusLabels[e.paymentStatus]}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
